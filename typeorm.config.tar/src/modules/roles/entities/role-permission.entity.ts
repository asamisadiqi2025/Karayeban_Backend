export class RolePermissionEntity {}
