import { registerAs } from '@nestjs/config';

export default registerAs('database', () => ({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT ?? 5432),
  username: process.env.DB_USERNAME,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,

  poolSize: Number(process.env.DB_POOL_SIZE ?? 10),

  logging: process.env.DB_LOGGING === 'true',

  synchronize: process.env.DB_SYNCHRONIZE === 'true',
}));